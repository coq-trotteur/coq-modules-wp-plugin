<?php
add_menu_page(
    'coq-trotteur',
    'coq-trotteur',
    'manage_options', // TODO
    'coq-trotteur',
    'adminPage', // TODO
    plugin_dir_url(__FILE__) . 'logo.png', // TODO
    2
);
