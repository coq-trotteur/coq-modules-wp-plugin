<?php

include('activity_page_template.php');
include('inspiration_page_template.php');
include('market_item_page_template.php');
include('section_page_template.php');
